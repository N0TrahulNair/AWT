require('dotenv').config();
//const url = 'mongodb://localhost:27017';
const { MongoClient } = require('mongodb');
const client = new MongoClient(process.env.url); // replace with url
console.log("Works");
async function run() {
    try {
        await client.connect();
        console.log("Correctly connected to the Server");
        const db = client.db('student')
        const studentDocument = {
            name: 'Pranav',
            age: '21',
            grades: [90, 80, 85],
            address: {
                street: '123 Street St.',
                city: 'Mumbai',
                state: 'MH',
                zip: '400050'
            }
        }
        const result = await db.collection('student').insertOne(studentDocument);
        console.log(`A document was inserted with id: ${result.insertedId}`);
    }
    catch (e) {
        console.error(e);
    }
    finally {
        client.close()
    }
}
run();