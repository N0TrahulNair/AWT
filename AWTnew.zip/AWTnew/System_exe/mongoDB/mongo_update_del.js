require('dotenv').config();
//const url = 'mongodb://localhost:27017';
const { MongoClient, ObjectId } = require('mongodb');
const client = new MongoClient(process.env.url); // replace with 'url'
const collectionName = 'student'

//! We need to use an async and await function as we are dealing with Promises and mongo return a Promise Object
async function findDocument(collection, query) {
    return collection.find(query).toArray();
}
async function deleteDocument(type, collection, query) {
    if (type == 1) return collection.deleteOne(query);
    else if (type == 2) return collection.deleteMany(query);
    else {
        console.error("ERROR");
    }
}
async function updateDocument(type, collection, query, update) {
    if (type == 1) return collection.updateOne(query, { $set: update });
    else if (type == 2) return collection.updateMany(query, { $set: update });
    else {
        console.error("ERROR");
    }
}
async function run() {
    try {
        //^Connection Part
        await client.connect();
        const db = client.db('student');
        const collection = db.collection('student')
        console.log('Connection Successfull');

        //*Finding a Document
        const find = await findDocument(collection, { name: 'Pranav' });
        console.log(`Found Documents: `);
        console.log(find);

        //*Deleting a Document
        //Type 1 - Delete One Document
        //Type 2 - Delete Many Documents
        const deleteDoc = await deleteDocument(2, collection, { name: 'Pranav' })
        console.log(`${deleteDoc.deletedCount} documents deleted`);

        //*Updating a Document
        //Type 1 - Updates One Document
        //Type 2 - Updates Many Documents
        const update = await updateDocument(1, collection, { name: 'Jake' }, { age: 70 });
        console.log(`${update.modifiedCount} documents updated`);
    }
    catch (e) {
        console.error(e);
    }
    finally {
        client.close();
    }
}
run();