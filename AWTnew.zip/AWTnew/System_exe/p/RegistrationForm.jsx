import React,{ useState } from 'react'

export const RegistrationForm = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [gender, setGender] = useState('');
    const [hobby, setHobby] = useState([]);

    const handleInputChange = (e) => {
        const {id ,value} = e.target;
        if(id === "firstName") setFirstName(value);
        if(id === "lastName") setLastName(value);
        if(id === "email") setEmail(value);
        if(id === "password") setPassword(value);
        if(id === "confirmPassword") setConfirmPassword(value);
        if(id === "gender") setGender(value);
    }
    const handleCheckboxChange = (e) =>{
        const {value, checked} = e.target;
        if(checked){
            setHobby([...hobby, value]);
        }
        else{
            setHobby(hobby.filter(hobby => hobby !== value));
        }
    }
    const handleSubmit = async(e) => {
        e.preventDefault();
        if(validate()){
            console.log(firstName, lastName, email, confirmPassword, gender, hobby);

            //^Express Form Part
            const formData = {
                firstName : firstName,
                lastName : lastName,
                email : email,
                password: password,
                gender : gender,
                hobby : hobby
            }
            try {
                const hostname = "localhost";
                const port = 4000;
                const response = await fetch(`http://${hostname}:${port}/submit-form`,{
                    method: "POST",
                    headers: {"Content-Type":"application/json"},
                    body: JSON.stringify(formData)
                })
                response.ok ? console.log("Form data submitted successfully") : console.error("ERROR OCCURED WHILE SUBMITTING FORM");
            } catch (error) {
                console.error(error);
            }
        }   
    }
    
    function validate() {
        if(firstName.length === 0 || lastName.length === 0 || email.length === 0 || password.length === 0 || gender === 0){
            alert("INVALID FORM, FIELDS CANNOT BE LEFT EMPTY");
            return false;
        }
        if(confirmPassword !== password){
            alert("PASSWORDS DO NOT MATCH");
            return false;
        }
        return true;
    }

    return(
        <div>
            <form onSubmit={handleSubmit}>
                <input type='text' id='firstName' value={firstName} onChange={handleInputChange} placeholder='First Name: '/><br/>
                <input type='text' id='lastName' value={lastName} onChange={handleInputChange} placeholder="Last Name: "/><br/>
                <input type='email' id='email' value={email} onChange={handleInputChange} placeholder="Email: "/><br/>
                <input type='text' id='password' value={password} onChange={handleInputChange} placeholder="Password: "/><br/>
                <input type='text' id='confirmPassword' value={confirmPassword} onChange={handleInputChange} placeholder="Confirm Password: "/><br/>
                <div>
                    <input type='radio' id='gender' name='gender' value="Male" checked={gender==="Male"} onChange={handleInputChange}/>Male
                    <input type='radio' id='gender' name='gender' value="Female" checked={gender==="Female"} onChange={handleInputChange}/>Female
                    <input type='radio' id='gender' name='gender' value="Others " checked={gender==="Others  "} onChange={handleInputChange}/>Others   
                </div>
                <div>
                    <input type='checkbox' id='sports' value="Sports" checked={hobby.includes("Sports")} onChange={handleCheckboxChange}/>Sports
                    <input type='checkbox' id='fishing' value="Fishing" checked={hobby.includes("Fishing")} onChange={handleCheckboxChange}/>Fishing
                    <input type='checkbox' id='gym' value="Gym" checked={hobby.includes("Gym")} onChange={handleCheckboxChange}/>Gym
                    <input type='checkbox' id='walking' value="Walking" checked={hobby.includes("Walking")} onChange={handleCheckboxChange}/>Walking
                </div>
                <button type='submit'>Submit Form</button>
             </form>
        </div>
    )
}
export default RegistrationForm;