const mysql = require("mysql2")
const express = require("express");

const hostname = 'localhost';
const port = 8080;

const app = express();
app.use(express.json());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "123456",
    database: "test",
    port: 3306
})

db.connect((err) => {
    !err ? console.log("DB Connected Successfully") : console.error("DB Connection Failed");
})

app.listen(port, hostname, () => {
    console.log(`Server is listening on http://${hostname}:${port}`);
})

app.get("/learner", (req, res) => {
    db.query("SELECT * FROM learner", (err, rows) => {
        !err ? res.send(rows) : res.send(err)
    })
});

app.get("/learner/:id", (req, res) => {
    db.query("SELECT * FROM learner WHERE id = ?", [req.params.id], (err, rows) => {
        !err ? res.send(rows) : res.send(err)
    })
})

app.delete("/learner/delete/:id", (req, res) => {
    db.query("DELETE FROM learner WHERE id = ?", [req.params.id], (err, rows) => {
        !err ? res.send(rows) : res.send(err)
    })
})

app.put("/learner/update/:id/:name/:age", (req, res) => {
    db.query("UPDATE learner SET name=?,age=? WHERE id=?", [req.params.name, req.params.age, req.params.id], (err, rows) => {
        !err ? res.send(rows) : res.send(err)
    })
})

app.get("/learner/insert/:id/:name/:age", (req, res) => {
    db.query("INSERT INTO learner VALUES (?,?,?)", [req.params.id, req.params.name, req.params.age], (err, result) => {
        if (!err) {
            res.send(result);
        } else {
            console.error(err);
        }
    });
});
