const mysql = require("mysql2/promise")
const express = require("express")
const cors = require("cors");

const hostname = 'localhost';
const port = 4000;

const app = express()
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "123456",
    database: "test",
    port: 3306
})

app.post("/submit-form", async (req, res) => {
    const firstName = req.body.firstName;
    const lastName = req.body.lastName;
    const email = req.body.email;
    const password = req.body.password;
    const gender = req.body.gender;

    const insertQuery = "INSERT INTO user(firstName, lastName, email, password, gender) VALUES (?,?,?,?,?)";
    try {
        const rows = await db.execute(insertQuery, [firstName, lastName, email, password, gender])
        console.log(rows + "\nUser Added to DB");
        res.send(rows)
    }
    catch (e) {
        console.error(e);
        res.status(500).send(e)
    }
})

app.listen(port, hostname, () => {
    console.log(`Server is listening at http://${hostname}:${port}`);
})