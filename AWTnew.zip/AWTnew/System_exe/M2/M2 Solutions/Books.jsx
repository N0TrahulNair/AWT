// SET B Question 2 Book Component. Route to different pages of a book website.

import  React,{useState} from 'react';

const books = [
    {
      id : 1,
      title:"Fourth Wing",
      author:"Rebecca Yaros",
      price: "$499"
    },
    {
      id : 2,
      title:"A Tale of 2 Cities",
      author:"Charles Dickens",
      price:"$599"
    },
    {
      id : 3,
      title:"Harry Potter",
      author:"JK Rowling",
      price:"$699"
    },
    {
      id : 4,
      title:"Lord of the Rings",
      author:"J.R.R Toklien",
      price:"$399"
    },
    {
      id : 5,
      title:"Obssesed",
      author:"James Patternson",
      price:"$649"
    },
    {
      id : 6,
      title:"It starts with us",
      author:"Collen Hoover",
      price:"$749"
    }
  ];
  const Bookp = (book) =>{
    return(
      <article className='content'>
        {<img src = {book.image}></img>}
        <h2>{book.title}</h2>
        <p className='authnm'>{book.author}</p>
        <p>{book.price}</p>
        <button className='btn'>Add to Cart</button>
      </article>
    )
  }
  const BookListp=()=>{
    return(
      <section className='booklist'>
        {
          books.map((book,id) => {
            return(
              <Bookp title={book.title} author={book.author} image = {book.image} price={book.price} key={id}/> 
            )
          })
        }
        
      </section>
    )
  }

export default BookListp;