import logo from './logo.svg';
import './App.css';
import  React,{useState} from 'react';
import Counter from './Counter';
import BookListp from './Books';
import Bookp from './Books';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Form from './FormValidations';
import Survey from './Survery';
import FormNavigate from './FormNavigate';
import FormNavigate1 from './FormNavigate';
import FormConsole from './FormConsole';
// SET B Question 2 Routing Components
// function Home(){
//   return(
//     <div>
//       <h1>This is the home page.</h1>
//     </div>
//   )

// }

// function Contact(){
//   return(
//     <div>
//       <h1>This is the Contact page.</h1>
//     </div>
//   )

// }


// function App() {
//   return (
//     <Router>
//     <div>
//         <h1>M2 SET B Question 2</h1>
//         <ul>
//           <li><Link to="/">Home</Link></li>
//           <li><Link to="/book">Book</Link></li>
//           <li><Link to="/contact">Contact</Link></li>
//         </ul>
//       </div> 
//       <Routes>
//         <Route path='/' exact element={<Home/>}></Route>
//         <Route path='/contact' exact element={<Contact/>}></Route>
//         <Route path='/book' exact element={<BookListp/>}></Route>
//       </Routes>
//       </Router>
//   );
// }

function App(){
    return(
        <div>
            {/* <Form/> */}
            {/* <Survey/> */}
            {/* <FormNavigate/> */}
            <FormConsole/>
        </div>
    )
}

export default App;
