// M2 SET B Question 3

import { useState } from "react";

function Form(){

    const[username,setUsername] = useState('')
    const[password,setPassword] = useState('')
    const[email,setEmail] = useState('')
    const[isSuccess,setIsSuccess] = useState(false);

    const handleInputChange = (e) => {
        const {id,value} = e.target;

        if(id === 'username'){
            setUsername(value);
        }
        if(id === 'password'){
            setPassword(value);
        }
        if(id === 'email'){
            setEmail(value);
        }
        
    }

    const handleSubmit = (event) => {
        event.preventDefault();

        console.log(username,email)

        //all
        if(username === ""){
            alert("Username Cannot be Empty");
            return
          }
          if(password === ""){
            alert("Password Cannot be Empty");
            return
          }
          if(email === ""){
            alert("Email Cannot be Empty");
            return
          }

        // password

        var upper = /[A-Z]/.test(password)
        var lower = /[a-z]/.test(password)
        var number = /[0-9]/.test(password)
        var special = /[!@#$%^&*()_+=-{}.,;'"]/.test(password)
        var len = password.length
        if(upper && lower && number && special && len>=8){
          console.log("Correct")
        }
        else{
          alert("Invalid Password.")
          return
        }

        //email
      var atIdx = email.indexOf("@")
      var dotIdx = email.indexOf(".")
      if(atIdx > 0 && dotIdx > atIdx + 1 && email.length > dotIdx){
          console.log('correct')
      }
      else{
          alert("Invalid Email")
          return
      }

      //checkbox
      let count = 0
      let data1 = event.target.tc['checked']

      if(!data1){
        alert('not chekced')
        return
      }
      console.log(data1)

      setIsSuccess(true)

    }

    return(
        <form onSubmit={handleSubmit}>
            <h1>Registration Form</h1>
            <label>Username : </label>
            <input type="text" name="username" id="username" onChange={handleInputChange}/><br/>
            <label>Password : </label>
            <input type="password" name="password" id="password" onChange={handleInputChange}/><br/>
            <label>Email : </label>
            <input type="text" name="email" id="email" onChange={handleInputChange}/><br/>
            <input type="checkbox" id="tc" name="tc"/>Terms and Conditions<br/>
            <input type="submit"/>
            {
            isSuccess && <p>Form Submitted</p>
          }
        </form>
    )
}

export default Form;