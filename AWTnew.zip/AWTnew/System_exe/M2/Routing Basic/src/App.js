import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router,Route,Routes,Link } from 'react-router-dom';
import { useState } from 'react';

const Home = () =>{
  return(
    <div>
      Home Page Content
    </div>
  )
}

const About = () =>{
  return(
    <div>
      About Page Content
    </div>
  )
}

const Contact = () =>{

  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');

  const handleInputChange = (e) =>{
    const {id,value} = e.target;


  }
  return(
    <div>
      <h1>Registration Form</h1>
      <form>
        <label>Name: </label>
        <input type='text' id='name' name='name' onChange={handleInputChange}/>
        <input type='text' id='email' name='email' onChange={handleInputChange}/>
        <input type='password' id='pass' name='name' onChange={handleInputChange}/>
      </form>
    </div>
  )
}


function App() {
  return (
    <Router>

      <div>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </div>

      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/contact' element={<Contact/>}></Route>
      </Routes>

    </Router>
  );
}

export default App;
