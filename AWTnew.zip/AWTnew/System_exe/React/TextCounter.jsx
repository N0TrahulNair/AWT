// Count the no. of text in a text field. Frontend only paste in src folder.

import React, { useState } from 'react';

function TextCounter() {
  const [text, setText] = useState('');

  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  return (
    <div>
      <h2>Text Length Counter</h2>
      <input type="text" value={text} onChange={handleTextChange} />
      <p>Length of the text: {text.length}</p>
    </div>
  );
}

export default TextCounter;
