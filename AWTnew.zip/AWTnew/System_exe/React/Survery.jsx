// Survery response is logging in node console. server file - SurveyServer.js. Paste this in src folder

import React, { useState } from 'react';

const Survey = () => {
  const [responses, setResponses] = useState({
    q1: '',
    q2: '',
    q3: '',
  });

  const handleChange = (questionId, value) => {
    setResponses({
      ...responses,
      [questionId]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:3001/submit-survey', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(responses),
      });
      const data = await response.json();
      console.log(data.message);
    } catch (error) {
      console.error('Error submitting survey:', error);
    }
  };

  return (
    <div>
      <h2>Survey Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="q1">Question 1: What is your favorite color?</label>
          <br />
          <input
            type="radio"
            id="q1-red"
            name="q1"
            value="red"
            onChange={() => handleChange('q1', 'red')}
          />
          <label htmlFor="q1-red">Red</label>
          <br />
          <input
            type="radio"
            id="q1-blue"
            name="q1"
            value="blue"
            onChange={() => handleChange('q1', 'blue')}
          />
          <label htmlFor="q1-blue">Blue</label>
          <br />
          <input
            type="radio"
            id="q1-green"
            name="q1"
            value="green"
            onChange={() => handleChange('q1', 'green')}
          />
          <label htmlFor="q1-green">Green</label>
        </div>
        <br />
        <div>
          <label htmlFor="q2">Question 2: What is your favorite animal?</label>
          <br />
          <input
            type="radio"
            id="q2-dog"
            name="q2"
            value="dog"
            onChange={() => handleChange('q2', 'dog')}
          />
          <label htmlFor="q2-dog">Dog</label>
          <br />
          <input
            type="radio"
            id="q2-cat"
            name="q2"
            value="cat"
            onChange={() => handleChange('q2', 'cat')}
          />
          <label htmlFor="q2-cat">Cat</label>
          <br />
          <input
            type="radio"
            id="q2-bird"
            name="q2"
            value="bird"
            onChange={() => handleChange('q2', 'bird')}
          />
          <label htmlFor="q2-bird">Bird</label>
        </div>
        <br />
        <div>
          <label htmlFor="q3">Question 3: How likely are you to recommend our product to a friend?</label>
          <br />
          <input
            type="radio"
            id="q3-likely"
            name="q3"
            value="likely"
            onChange={() => handleChange('q3', 'likely')}
          />
          <label htmlFor="q3-likely">Likely</label>
          <br />
          <input
            type="radio"
            id="q3-neutral"
            name="q3"
            value="neutral"
            onChange={() => handleChange('q3', 'neutral')}
          />
          <label htmlFor="q3-neutral">Neutral</label>
          <br />
          <input
            type="radio"
            id="q3-unlikely"
            name="q3"
            value="unlikely"
            onChange={() => handleChange('q3', 'unlikely')}
          />
          <label htmlFor="q3-unlikely">Unlikely</label>
        </div>
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Survey;
