// Server code for FormConsole.jsx. Paste in src/server

console.log("Hello")

const express = require('express');
const app = express();
const port = 4001;
const cors = require('cors');
app.use(cors()); 

app.use(express.json());


app.use(express.urlencoded({ extended: true }));

app.post('/submit-form', (req, res) => {

  console.log(req.body)
  const username = req.body.username;
  const password = req.body.password;

  console.log(`Firstname : ${username}, Lastname:${password}`);
  res.send(`Username: ${username}, Password: ${password}`);
});

// Start the server

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});