// server code paste in src/server

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3001;
app.use(cors())
app.use(bodyParser.json());

app.post('/submit-survey', (req, res) => {
  const responses = req.body;
  // Process and analyze the survey responses here
  console.log('Survey responses:', responses);
  res.json({ message: 'Survey response received successfully!' });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
