// To insert username and password values in SQL Table. server file = sql.js

import { useState } from "react";

function FormAuthenitcation(){

    const[username,setUsername] = useState('')
    const[password,setPassword] = useState('')

    const handleInputChange = (e) => {
        const {id,value} = e.target;

        if(id === 'username'){
            setUsername(value);
        }
        if(id === 'password'){
            setPassword(value);
        }
    }

    const handleSubmit = async(event) => {
        event.preventDefault();

      const data = {
        'username' : username,
        'password': password
      }

      // Code if you are using index.js (Display form data in Terminal)
      const response = await fetch('http://localhost:4001/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      console.log(response)

      if (response.ok) {
        console.log('Form submitted successfully');
        
      } else {
        console.log('Form submission failed');
        
      }
    }

    return(
        <form onSubmit={handleSubmit}>
            <h1>Registration Form</h1>
            <label>Username : </label>
            <input type="text" name="username" id="username" onChange={handleInputChange}/><br/>
            <label>Password : </label>
            <input type="password" name="password" id="password" onChange={handleInputChange}/><br/>
            <input type="submit" />
        </form>
    )
}

export default FormAuthenitcation;