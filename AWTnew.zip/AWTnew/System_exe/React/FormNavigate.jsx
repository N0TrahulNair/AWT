// Routing to new page after form gets submitted using react router. No server file for this only frontend paste in src folder and render in App.js

import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
 
 
const FormNavigate = () => {
  // navigate variable is created
  const navigate = useNavigate();
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  const [checkbox, setCheckbox] = useState(false)
 
  const handleInputChange = (e) => {
    const name = e.target.name
    const value = e.target.value
 
    if (name === 'username') {
      setUsername(value)
    } else if(name === 'password') {
      setPassword(value)
    } else if(name === 'email'){
      setEmail(value)
    }
  }
 
  const handleSubmit = (e) => {
    e.preventDefault()
 
    if (username === '') {
      alert("Please enter valid username")
      return
    }

    //email
    var atIdx = email.indexOf("@")
    var dotIdx = email.indexOf(".")
    if(atIdx > 0 && dotIdx > atIdx + 1 && email.length > dotIdx){
        console.log('correct')
    }
    else{
        alert("Invalid Email")
        return
    }
 
    //password
    var upper = /[A-Z]/.test(password)
    var lower = /[a-z]/.test(password)
    var number = /[0-9]/.test(password)
    var special = /[!@#$%^&*()_+=-{}.,;'"]/.test(password)
    var len = password.length
    if(upper && lower && number && special && len>=8){
      console.log("Correct")
    }
    else{
      alert("Invalid Password.")
      return
    }
 
 
    alert(username + " " + password + " " + email + " " + checkbox)
    navigate('/home')
 
    // fetch('http://localhost:4001/survey', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ username, password }),
    // })
 
 
  }
 
 
  return (
    <div>
      <form onSubmit={handleSubmit}>
        Enter Name:
        <input type='text' name='username' value={username} onChange={handleInputChange} />
 
        Enter password:
        <input type='password' name='password' value={password} onChange={handleInputChange} />

        Enter email:
        <input type='email' name='email' value={email} onChange={handleInputChange} />

        terms and conditions   
        <input type='checkbox' name='checkbox' value={checkbox} onChange={handleInputChange} />
 
 
        <br />
        <button type='submit'>Click to submit</button>
      </form>
    </div>
  )
}
 
const HomePage = () => {
  return (
    <div>
      this is post page of the user
    </div>
  )
}
 
const FormNavigate1 = () => {
  return (
    <Router>
      <Routes>
        <Route path='/home' element={<HomePage />} />
        <Route path='/' exact element={<FormNavigate />} />
      </Routes>
    </Router>
  )
}

export default FormNavigate1;
