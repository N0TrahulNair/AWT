// Displaying SQL Table data on react website. server file = sql_table.js

import React, { useState } from 'react';
import './App.css';

function App() {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:3001/data');
      const jsonData = await response.json();
      setData(jsonData);
      console.log(jsonData);
      console.log("Data variable",data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleFetchData = () => {
    fetchData();
  };

  return (
    <div className="App">
      <h1>MySQL Data</h1>
      <button onClick={handleFetchData}>Fetch Data</button>
      <table className='App' border='1px'>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              <td>{item.ID}</td>
              <td>{item.Name}</td>
              <td>{item.Email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
