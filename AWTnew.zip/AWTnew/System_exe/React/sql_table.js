// server file of SqlTable.jsx. Paste in src/server

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3001;

// MySQL Connection
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'root',
  database: 'awt_final',
  port:3309
});

connection.connect();

app.use(cors());

// Route to fetch data from MySQL
app.get('/data', (req, res) => {
  connection.query('SELECT * FROM user', (error, results, fields) => {
    if (error) throw error;
    res.json(results);
    console.log(results)
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
