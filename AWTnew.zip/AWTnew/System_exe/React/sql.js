// FormAuthentication Server code. Paste in src/server

console.log("Hello")
const mysql = require('mysql2')
const express = require('express');
const app = express();
const port = 4001;
const cors = require('cors');


const conn = mysql.createConnection({
  host: '127.0.0.1',
  database: 'mad',
  user: 'root',
  password: 'root',
  port: 3309
})

conn.connect((err) => {
  if(err) return  console.log(err)
  console.log('db success')

})


app.use(cors()); 

app.use(express.json());


app.use(express.urlencoded({ extended: true }));

app.post('/register', async(req, res) => {

    console.log(req.body)
    const username = req.body.username;
    const password = req.body.password;

    const insertQuery = `INSERT INTO users (username,password) VALUES (?,?)`;

    try{

        const data = await conn.execute(insertQuery, [username,password])

        res.send('User Registered')
        console.log("User Registered")
    }
    catch (error){
        console.error("Failed : " , error)
        res.status(500).send('Failed to register')
    }

  });

  app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
  });