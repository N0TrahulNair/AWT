const mysql = require("mysql2")
const express = require("express");

const hostname = 'localhost';
const port = 8080;

const app = express();
app.use(express.json());

const db = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "root",
    database: "awt",
    port: 3309
})

db.connect((err) => {
    !err ? console.log("DB Connected Successfully") : console.error("DB Connection Failed");
})

app.listen(port, hostname, () => {
    console.log(`Server is listening on http://${hostname}:${port}`);
})

app.get("/users", (req, res) => {
    db.query("SELECT * FROM users", (err, rows) => {
        !err ? res.send(rows) : res.send(err)
    })
});

app.get("/users/:id", (req, res) => {
    db.query("SELECT * FROM users WHERE id = ?", [req.params.id], (err, rows) => {
        if (!err) {
            res.send(rows);
        } else {
            console.error(err);
        }
    })
})

app.get("/users/delete/:id", (req, res) => {
    db.query(`DELETE FROM users WHERE id=?`, [req.params.id], (err, result) => {
        if (!err) {
            if (result.affectedRows > 0) {
                console.log(`Deleted users`);
                res.status(200).send("users deleted successfully");
            } else {
                console.log(`No users found`);
                res.status(404).send("No users found with the specified ID");
            }
        } else {
            console.error(err);
            res.status(500).send("Error deleting users");
        }
    })
})

app.get("/users/update/:name/:id", (req, res) => {
    db.query(`UPDATE users SET name=? WHERE id=?`, [req.params.name, req.params.id], (err, result) => {
        if (!err) {
            res.send(result);
        } else {
            console.error(err);
        }
    })
})

app.get("/users/insert/:id/:name/:course", (req, res) => {
    db.query(`INSERT INTO users VALUES (?,?,?)`, [req.params.id, req.params.name, req.params.course], (err, result) => {
        if (!err) {
            res.send(result);
        } else {
            console.error(err);
        }
    });
});
